print(float(0))
print(int(-112.22))
print(bool(12.22))
print(bool(0))
# print(int('')) برای تهی عدد صحیحی وجود ندارد
print(str(float('-12.22')))
print(float(True))
# print(int('12/5')) ابتدا باید به اعشاری تبدیل شود و سپس صحیح
print(bool('0'))
# print(int(str(bool(12.345)))) عدد صحیحی برای رشته ی true وجود ندارد



